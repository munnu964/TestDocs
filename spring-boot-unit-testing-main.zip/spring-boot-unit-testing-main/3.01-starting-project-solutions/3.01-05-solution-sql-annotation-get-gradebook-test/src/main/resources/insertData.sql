insert into student(id,firstname,lastname,email_address) values (11, 'Student', 'One', 'student.one@luv2code_school.com')
insert into student(id,firstname,lastname,email_address) values (12, 'Student', 'Two', 'student.two@luv2code_school.com')
insert into student(id,firstname,lastname,email_address) values (13, 'Student', 'Three', 'student.three@luv2code_school.com')
insert into student(id,firstname,lastname,email_address) values (14, 'Student', 'Four', 'student.four@luv2code_school.com')